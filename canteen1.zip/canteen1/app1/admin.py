from django.contrib import admin
from .models import users_reg,users_login
# Register your models here.

admin.site.register(users_reg)
admin.site.register(users_login)