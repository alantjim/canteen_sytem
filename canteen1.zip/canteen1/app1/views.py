from django.shortcuts import render,redirect
from .models import users_reg,users_login
from django.contrib.auth import login,logout

# Create your views here.
def index(request):
     return render (request,"home.html")





def login1(request):
    request.session['email'] = 'null'
    request.session['password'] = 'null'

    if request.method == "POST":
        email=request.POST.get("email")
        password =request.POST.get("pass")
        type = request.POST.get("type")

        user=users_login.objects.filter(email=email,password=password,type=type)
        if user:
            request.session['email'] =email
            request.session['password'] = password
            request.session['type'] = type


            #log_dts=users_login.objects.all()
            #reg_dts = users_reg.objects.all()
            # email=log_dts.email
            #request.session['uid']=
            # request.session['email'] = email
            return redirect ('user1/')
        else:
               return redirect('/login/')
    return render(request,'index.html')




def user1(request):

   if request.session['email'] == 'null':
       return redirect('/login/')
   # id=request.session['uid']
   elif 'email' in request.session:
     email=request.session['email']
     content = {
         'l_det': users_login.objects.all(),
         'r_det': users_reg.objects.all(),

         'email': email
     }
     return render(request, 'user1.html', content)
   return render(request, "home.html")





def cpass(request):
   password=request.session['password']
   if request.method == "POST":
        pwd =request.POST.get("pwd")
        n_pwd = request.POST.get("n_pwd")
        cn_pwd = request.POST.get("c_pwd")
        l_det= users_login.objects.all()
        for d in l_det:
         if pwd == password and n_pwd == cn_pwd:
            new_log = users_login(password=n_pwd)
            new_log.save()
            return render(request, "/profile/")
        else:
            return render(request, "/")
   if request.session['email'] == 'null':
    return redirect('/login/')
   return render(request, "cpass.html")






def student(request):
    if request.method=="POST":
        uid = request.POST.get("uid")
        luid=request.POST.get("uid")
        f_name=request.POST.get("f_name")
        l_name = request.POST.get("l_name")
        mobile = request.POST.get("m_number")
        type = request.POST.get("type")
        depart = request.POST.get("depart")
        email = request.POST.get("email")
        password=request.POST.get("password")

        new_reg=users_reg(uid=uid,f_name=f_name,l_name=l_name,mobile=mobile,depart=depart)
        new_reg.save()
        new_log = users_login(uid2=luid,type=type, email=email, password=password)
        new_log.save()
        return redirect('/')

    return render (request,"reg_stu.html")





def profile(request):

    #reg=users_reg.objects.all()
    email=request.session['email']
    type = request.session['type']

    if request.session['email'] == 'null':
        return redirect('/login/')

    if request.user.is_authenticated:
     content={
         'l_det':users_login.objects.all(),
         'r_det':users_reg.objects.all(),

         'email':email
     }
     return render(request,"profile.html",content)





def logout(request):
    request.session['email'] = 'null'
    request.session['password'] = 'null'
    return redirect('/login/')



