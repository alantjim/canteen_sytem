from django.db import models

# Create your models here.
uid=0

class users_reg(models.Model):
    uid=models.CharField(max_length=8,primary_key=True,)
    f_name = models.CharField(max_length=30)
    l_name = models.CharField(max_length=30)
    mobile = models.IntegerField()
    depart=models.CharField(max_length=10)

    def __str__(self):
        return str(self.uid),(self.f_name),(self.l_name),(self.mobile),(self.depart)


class users_login(models.Model):
    uid2= models.CharField(primary_key=True,max_length=8)
    email = models.CharField(max_length=30, unique=True, )
    password = models.CharField(max_length=15)
    type = models.CharField(max_length=10)

    def __str__(self):
        return str(self.uid2), (self.email), (self.password), (self.type)



